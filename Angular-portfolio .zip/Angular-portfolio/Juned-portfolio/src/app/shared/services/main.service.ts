import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Experience, Post, Project, User } from '@models';
import { Bio } from 'src/app/models/Bio';
import { tap } from 'rxjs/operators';
import { Education } from 'src/app/models/Education.interface';
import { Internship } from 'src/app/models/internship.interface';


@Injectable({
  providedIn: 'root',
})
export class MainService {
  BLOG_API = 'https://blog.uspiri.com/api';
  CV_API = 'https://cv.uspiri.com/api';
  BIO = 'http://localhost:4000/Bio';
  Skills = 'http://localhost:4000/skills';
  Projects = 'http://localhost:4000/projects';
  Experiences = 'http://localhost:4000/experiences';
  Education = "http://localhost:4000/education";
  Internship = "http://localhost:4000/Internships";

  // private http = inject(HttpClient);
  
constructor(readonly http :HttpClient){

}
  getPosts() {
    return this.http.get<Post[]>(`${this.BLOG_API}/posts/latests.json`);
  }
  getBio(){
    return this.http.get<Bio[]>(`${this.BIO}`);
  }
  
  getExperience() {
    return this.http.get<Experience[]>(`${this.Experiences}`);
  }

  getEducation() {
    return this.http.get<Education[]>(`${this.Education}`);
  }
  getInternship() {
    return this.http.get<Internship[]>(`${this.Internship}`);
  }
  getProjects() {
    return this.http.get<Project[]>(`${this.Projects}`);
  }

  getSkills() {
    return this.http.get<string[]>(`${this.Skills}`);
  }

  getUser() {
    return this.http.get<User>(`${this.BIO}`);
  }
}
