export const SKILLS = [
  'Angular',
  'HTML',
  'CSS',
  'Bootstrap',
  'dotnet',
  'java'
];
