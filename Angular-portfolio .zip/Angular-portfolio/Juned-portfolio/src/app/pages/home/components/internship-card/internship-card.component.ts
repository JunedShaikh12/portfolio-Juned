import { Component, Input } from '@angular/core';
import { LinkIconComponent } from '@shared/components/link-icon/link-icon.component';
import { Internship } from 'src/app/models/internship.interface';

@Component({
  selector: 'app-internship-card',
  standalone: true,
  imports: [LinkIconComponent],
  template: `
   <article
      class="group/item flex flex-col rounded-lg border-neutral-800 py-3 transition-all hover:scale-[102%] md:flex-row md:items-center md:gap-6"
    >
      <div
        class="w-32 shrink-0 font-medium text-neutral-400 transition-all group-hover/item:text-cyan-500 md:text-right"
      >
        {{ Internship.startDate }} - {{ Internship.endDate }}
      </div>
      <div class="flex flex-col gap-1">
        <h3 class="flex items-center gap-2 text-2xl font-semibold">
          @if (Internship.url) {
            <a
              [href]="Internship.url"
              class="hover:underline"
              target="_blank"
              rel="noopener noreferrer"
            >
              {{ Internship.company }}
            </a>
            <app-link-icon class="h-4 w-4 fill-neutral-50" />
          } @else {
            {{ Internship.company }}
          }
        </h3>
        <p class="text-sm font-medium text-neutral-300">
          {{ Internship.position }}
        </p>
         <p class="text-sm font-medium text-neutral-300">
          {{ Internship.location }}
        </p>
        <p class="text-sm text-neutral-400">
          {{ Internship.description }}
        </p>
      </div>
    </article>
  `,
})
export class InternshipCardComponent {
  @Input({ required: true }) Internship!: Internship;
}
