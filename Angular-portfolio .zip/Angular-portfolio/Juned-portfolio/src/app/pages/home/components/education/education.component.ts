import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { TitleComponent } from '@shared/components/title/title.component';
import { MainService } from '@shared/services/main.service';
import { Education } from 'src/app/models/Education.interface';
import { EducationCardComponent } from '../education-card/education-card.component';
import { LinkButtonComponent } from '@shared/components/link-button/link-button.component';

@Component({
  selector: 'app-education',
  standalone: true,
  imports: [CommonModule,TitleComponent,EducationCardComponent,LinkButtonComponent],
  template: `

   <section id="education">
      <app-title>Education</app-title>
      <ul class="mt-10 flex flex-col gap-3">
        @for (Education of Educations; track $index) {
          <li>
            <app-education-card [Education]="Education" />
          </li>
        }
      </ul>
      <app-link-button
        href="https://cv.uspiri.com"
        btnStyle="base"
        class="mt-8 flex underline"
        >Read more...</app-link-button
      >
    </section>
  `
})

export class EducationComponent implements OnInit {
    constructor(private readonly mainService:MainService){
    }
    Educations: Education[] = [];

    ngOnInit() {
        this.mainService
        .getEducation()
        .subscribe((Education) => {
          this.Educations = Education
          console.log('Educationn',this.Educations);
        });
    }   
}




