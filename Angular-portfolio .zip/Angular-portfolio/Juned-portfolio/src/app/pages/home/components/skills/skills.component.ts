import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { TitleComponent } from '@shared/components/title/title.component';
import { MainService } from '@shared/services/main.service';

@Component({
  selector: 'app-skills',
  imports: [TitleComponent, CommonModule],
  standalone: true,
  template: `
    <section id="skills">
      <app-title>Skills</app-title>
      <div *ngFor="let category of skills; let categoryIndex = index">
        <h3 class="text-xl font-semibold text-neutral-600">{{ category.title }}</h3>
        <ul class="mt-6 flex flex-wrap justify-center gap-4">
          <li
            *ngFor="let skill of category.skills; let skillIndex = index"
            class="select-none rounded-md border border-neutral-600 px-2 py-1 text-base font-semibold text-neutral-400 transition-all hover:scale-105 hover:text-cyan-500"
          >
          <img [src]="skill.image" alt="{{ skill.name }}" class="w-6 h-6 rounded-full" />
            {{ skill.name }}
          </li>
        </ul>
      </div>
    </section>
  `,
  styles: [
    `
      #skills {
        padding: 2rem;

        app-title {
          margin-bottom: 1rem;
        }

        h3 {
          margin-top: 2rem;
          margin-bottom: 1rem;
        }

        ul {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          gap: 1rem;
        }

        li {
          border-radius: 8px;
          border: 1px solid #e2e8f0;
          padding: 0.5rem 1rem;
          font-size: 1rem;
          font-weight: 600;
          text-align: center;
          color: #4a5568;
          transition: all 0.3s;

          &:hover {
            transform: scale(1.05);
            color: #38b2ac;
          }
            img {
            width: 30px;
            height: 30px;
            object-fit: contain;
            border-radius: 50%;
          }
            span {
            font-size: 0.875rem;
            margin-left: 0.5rem;
          }
            
        }
      }
    `,
  ],
})
export class SkillsComponent implements OnInit {
  private mainService = inject(MainService);
  skills: any[] = [];

  ngOnInit() {
    this.mainService.getSkills().subscribe((data) => {
      this.skills = data;
      console.log('Skills data:', data);
    });
  }
}
