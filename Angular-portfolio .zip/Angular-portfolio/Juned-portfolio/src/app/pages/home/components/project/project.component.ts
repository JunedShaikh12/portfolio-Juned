import { Component, Input } from '@angular/core';
import { BadgeComponent } from '@shared/components/badge/badge.component';
import { ButtonComponent } from '@shared/components/button/button.component';
import { GithubIconComponent } from '@shared/components/github-icon/github-icon.component';
import { InfoIconComponent } from '@shared/components/info-icon/info-icon.component';
import { LinkButtonComponent } from '@shared/components/link-button/link-button.component';
import { LinkIconComponent } from '@shared/components/link-icon/link-icon.component';
import { Project } from 'src/app/models/project.interface';

@Component({
  selector: 'app-project',
  standalone: true,
  imports: [
    ButtonComponent,
    LinkButtonComponent,
    GithubIconComponent,
    LinkIconComponent,
    InfoIconComponent,
    BadgeComponent,
  ],
  template: `
   <article
      class="project-card rounded-lg border border-neutral-800 px-5 py-4 transition-all hover:scale-[102%] hover:border-cyan-600"
    >
      <header
        class="mb-3 flex flex-row flex-wrap items-center gap-3 animate__animated animate__fadeInDown"
      >
        <h3
          class="text-nowrap text-xl font-semibold transition-all md:text-2xl hover:animate-wiggle"
        >
          ⭐ {{ project.name }} ⭐ {{ project.title }}
        </h3>
        <ul class="flex flex-wrap gap-3">
          @for (tag of project.tags; track $index) {
            <li class="animate__animated animate__pulse animate__infinite">
              <app-badge [label]="tag" />
            </li>
          }
        </ul>
      </header>
      <p
        class="mb-4 text-sm leading-snug text-neutral-400 sm:text-base animate__animated animate__fadeIn"
      >
        {{ project.description }}
      </p>
      <footer class="flex gap-2">
        @if (project.url) {
          <app-link-button
            class="transition-transform duration-300 hover:scale-110"
            [href]="project.url"
            title="{{ project.name }} page"
          >
            <app-link-icon class="h-4 w-4" />
          </app-link-button>
        }
        @if (project.repo) {
          <app-link-button
            class="transition-transform duration-300 hover:rotate-12"
            [href]="project.repo"
            title="{{ project.name }} repository"
          >
            <app-github-icon class="h-4 w-4" />
          </app-link-button>
        }
      </footer>
    </article>
  `,
  
  styles: [
    `
      .project-card {
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
      }

      .project-card:hover {
        box-shadow: 0 4px 20px rgba(0, 255, 255, 0.3);
        transform: translateY(-5px);
      }
      .hover\\:animate-wiggle:hover {
        animation: wiggle 0.5s ease-in-out infinite;
      }`]
})
export class ProjectComponent {
  @Input({ required: true }) project!: Project;
}
