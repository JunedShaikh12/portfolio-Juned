import { Component, Input } from '@angular/core';
import { LinkIconComponent } from '@shared/components/link-icon/link-icon.component';
import { Education } from 'src/app/models/Education.interface';

@Component({
  selector: 'app-education-card',
  standalone: true,
  imports: [LinkIconComponent],
  template: `
   <article
  class="group/item flex flex-col rounded-lg border border-neutral-800 bg-neutral-950 py-4 px-6 shadow-lg transition-all hover:scale-[102%] hover:border-neutral-700 hover:shadow-2xl md:flex-row md:items-center md:gap-6"
>
  <!-- Header (School) -->
  

  <!-- Content -->
  <div class="flex flex-col gap-2 text-neutral-400">
    <!-- School / University -->
    <h3 class="flex items-center gap-2 text-2xl font-semibold text-neutral-300">
      @if (Education.url) {
        <a
          [href]="Education.url"
          class="hover:underline text-neutral-200 transition-colors duration-300"
          target="_blank"
          rel="noopener noreferrer"
        >
          {{ Education.school }}
        </a>
        <app-link-icon class="h-4 w-4 fill-neutral-300" />
      } @else {
        {{ Education.school }}
      }
    </h3>

    <!-- University -->
    <p class="text-sm font-medium text-neutral-500">
      University: {{ Education.University }}
    </p>

    <!-- Date -->
    <p class="text-sm text-neutral-500">Date: {{ Education.date }}</p>

    <!-- CGPA -->
    <p class="text-sm text-neutral-500">CGPA: {{ Education.CGPA }}</p>

    <!-- Percentage -->
    <p class="text-sm text-neutral-500">Percentage: {{ Education.percentage }}</p>

    <!-- Grade -->
    <p class="text-sm text-neutral-500">Grade: {{ Education.Grade }}</p>

    <!-- Degree -->
    <p class="text-sm text-neutral-500">Degree: {{ Education.degree }}</p>

    <!-- Description -->
    <p class="text-sm text-neutral-500 leading-relaxed">
      {{ Education.desc }}
    </p>
  </div>
</article>

  `,
})
export class EducationCardComponent {
  @Input({ required: true }) Education!: Education;
}
