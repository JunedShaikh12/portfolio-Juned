import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { TitleComponent } from '@shared/components/title/title.component';
import { MainService } from '@shared/services/main.service';
import { LinkButtonComponent } from '@shared/components/link-button/link-button.component';
import { Internship } from 'src/app/models/internship.interface';
import { InternshipCardComponent } from '../internship-card/internship-card.component';

@Component({
  selector: 'app-internship',
  standalone: true,
  imports: [CommonModule,TitleComponent,LinkButtonComponent,InternshipCardComponent],
  template: `
  <section id="internship">
      <app-title>Internship</app-title>
      <ul class="mt-10 flex flex-col gap-3">
        @for (Internship of Internship; track $index) {
          <li>
            <app-internship-card [Internship]="Internship" />
          </li>
        }
      </ul>
      <app-link-button
        href=""
        btnStyle="base"
        class="mt-8 flex underline"
        >Read more...</app-link-button
      >
    </section>
  `
})

export class InternshipComponent implements OnInit {
    constructor(private readonly mainService:MainService){
    }
    Internship: Internship[] = [];

    ngOnInit() {
        this.mainService
        .getInternship()
        .subscribe((internship) => {
          this.Internship = internship
          console.log('Internship',this.Internship);
        });
    }   
}




