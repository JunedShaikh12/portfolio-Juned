import { Component, OnInit, inject } from '@angular/core';
import { Post } from '@models';
import { PostComponent } from '../post/post.component';
import { TitleComponent } from '@shared/components/title/title.component';
import { MainService } from '@shared/services/main.service';
import { LinkButtonComponent } from '@shared/components/link-button/link-button.component';
import { Bio } from 'src/app/models/Bio';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-blog',
  standalone: true,
  imports: [PostComponent, TitleComponent, LinkButtonComponent, CommonModule],
  template:``
  // template: `
  //   <section id="blog">
  //     <!-- Blog Header -->
  //     <hgroup class="flex items-baseline gap-2">
  //       <app-title></app-title>
  //       <span class="text-xs font-semibold text-neutral-400"></span>
  //     </hgroup>

  //     <!-- Blog Posts -->
  //     <ul class="blog-list">
  //       <li *ngFor="let bio of Bio" class="blog-item">
  //         <div class="blog-card">
  //           <h2 class="blog-name">{{ bio.name }}</h2>
  //           <p class="blog-roles">
  //             <strong>Roles:</strong>
  //             <span *ngFor="let role of bio.roles; let last = last">
  //               {{ role }}<span *ngIf="!last">, </span>
  //             </span>
  //           </p>
  //           <p class="blog-description">
  //             <strong>Description:</strong> {{ bio.description }}
  //           </p>
  //         </div>
  //       </li>
  //     </ul>

  //     <!-- Read More Button -->
  //     <app-link-button
  //       href="https://blog.uspiri.com"
  //       btnStyle="base"
  //       class="read-more-btn"
  //     >
  //       Read more...
  //     </app-link-button>
  //   </section>
  // `,
  // styles: [
  //   `
  //     #blog {
  //       padding: 2rem;

  //       hgroup {
  //         display: flex;
  //         align-items: baseline;
  //         gap: 0.5rem;
  //         margin-bottom: 1rem;

  //         app-title {
  //           font-size: 1.75rem;
  //           font-weight: bold;
  //         }

  //         span {
  //           color: #718096;
  //         }
  //       }

  //       .blog-list {
  //         display: flex;
  //         flex-direction: column;
  //         gap: 1.5rem;

  //         @media (min-width: 768px) {
  //           flex-direction: row;
  //           flex-wrap: wrap;
  //           justify-content: space-between;
  //         }

  //         .blog-item {
  //           flex: 1 0 40%;
  //           max-width: 40%;
  //           display: flex;

  //           .blog-card {
  //             background-color: #fff;
  //             border: 1px solid #e2e8f0;
  //             border-radius: 8px;
  //             padding: 1.5rem;
  //             box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  //             width: 100%;
  //             transition: box-shadow 0.3s;

  //             &:hover {
  //               box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  //             }

  //             .blog-name {
  //               font-size: 1.25rem;
  //               font-weight: bold;
  //               color: #2d3748;
  //               margin-bottom: 0.5rem;
  //             }

  //             .blog-roles {
  //               font-size: 0.875rem;
  //               color: #4a5568;
  //               margin-bottom: 0.5rem;

  //               strong {
  //                 color: #2d3748;
  //               }
  //             }

  //             .blog-description {
  //               font-size: 0.875rem;
  //               color: #4a5568;

  //               strong {
  //                 color: #2d3748;
  //               }
  //             }
  //           }
  //         }
  //       }

  //       .read-more-btn {
  //         margin-top: 2rem;
  //         display: flex;
  //         justify-content: center;
  //         font-size: 1rem;
  //         color: #3182ce;
  //         text-decoration: underline;

  //         &:hover {
  //           color: #2b6cb0;
  //         }
  //       }
  //     }
  //   `,
  // ],
})
export class BlogComponent implements OnInit {
  private mainService = inject(MainService);

  Bio: Bio[] = [];

  ngOnInit() {
    this.mainService.getBio().subscribe((Bio) => {
      this.Bio = Bio;
      console.log('Fetched Bio:', this.Bio);
    });
  }
}
