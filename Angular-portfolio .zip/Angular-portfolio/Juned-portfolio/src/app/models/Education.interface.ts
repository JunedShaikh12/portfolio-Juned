export interface Education{
    id?: number;
    school?:string;
    University?:string;
    date?: any;
    CGPA?:any;
    percentage?:any;
    Grade?:string;
    desc?:string;
    degree?:string;
    url?:any;
  }  


  