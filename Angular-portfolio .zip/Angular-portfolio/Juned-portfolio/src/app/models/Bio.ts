export interface Bio{
  id:string;
  title: string;
  tags: string[];
  url: string;
  date: Date;
  name:string;
  roles:string;
  description:string;
  github:string;
  resume:string;
  linkedin:string;
}