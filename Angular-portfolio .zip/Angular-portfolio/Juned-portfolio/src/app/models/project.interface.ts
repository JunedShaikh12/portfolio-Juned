export interface Project {
  id?:string;
  title?: string;
  name?: string;//
  description: string;
  url?: string;
  repo?: string;
  tags: string[];
  date?:string;
  github:any;
}
